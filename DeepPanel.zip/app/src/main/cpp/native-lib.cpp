#include <jni.h>
#include <android/log.h>
#include <unistd.h>
#include <pthread.h>
#include <signal.h>

#define LOG_TAG "DeepPanel"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)

void trigger_kill_switch() {
    LOGI("Versao incompativel. Fechando...");
    kill(getpid(), SIGKILL);
}

void* hack_thread(void*) {
    // AQUI ENTRA A LOGICA DO AIMBOT E ESP (LEITURA DO IL2CPP)
    // Kill switch ativado para segurança contra updates da Garena
    trigger_kill_switch();
    return nullptr;
}

__attribute__((constructor)) void lib_main() {
    pthread_t pt;
    pthread_create(&pt, NULL, hack_thread, NULL);
}

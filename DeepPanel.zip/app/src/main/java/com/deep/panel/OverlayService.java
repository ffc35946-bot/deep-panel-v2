package com.deep.panel;
import android.app.Service;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.os.IBinder;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.Switch;
import android.widget.TextView;

public class OverlayService extends Service {
    private WindowManager windowManager;
    private LinearLayout menuView;
    private boolean isHidden = false;
    private float startY = 0;
    public static boolean aimbotEnabled = false;
    public static boolean espEnabled = false;

    @Override
    public void onCreate() {
        super.onCreate();
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        
        menuView = new LinearLayout(this);
        menuView.setOrientation(LinearLayout.VERTICAL);
        menuView.setBackgroundColor(Color.parseColor("#1E1E2E")); // Fundo DeepSeek
        menuView.setPadding(40, 40, 40, 40);

        TextView title = new TextView(this);
        title.setText("DEEP PANEL");
        title.setTextColor(Color.parseColor("#4D6BFE")); // Azul DeepSeek
        title.setTextSize(22);
        menuView.addView(title);

        Switch aimbotSwitch = new Switch(this);
        aimbotSwitch.setText("Aimbot");
        aimbotSwitch.setTextColor(Color.WHITE);
        aimbotSwitch.setOnCheckedChangeListener((buttonView, isChecked) -> { aimbotEnabled = isChecked; });
        menuView.addView(aimbotSwitch);

        Switch espSwitch = new Switch(this);
        espSwitch.setText("ESP Box");
        espSwitch.setTextColor(Color.WHITE);
        espSwitch.setOnCheckedChangeListener((buttonView, isChecked) -> { espEnabled = isChecked; });
        menuView.addView(espSwitch);

        int layoutFlag = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE;
        WindowManager.LayoutParams params = new WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY, layoutFlag, PixelFormat.TRANSLUCENT);
        params.gravity = Gravity.TOP | Gravity.START;
        params.x = 100; params.y = 100;

        menuView.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                if (event.getPointerCount() == 3) {
                    switch (event.getActionMasked()) {
                        case MotionEvent.ACTION_DOWN: startY = event.getY(); break;
                        case MotionEvent.ACTION_UP:
                            float deltaY = event.getY() - startY;
                            if (deltaY > 200 && !isHidden) { menuView.setVisibility(View.GONE); isHidden = true; }
                            else if (deltaY < -200 && isHidden) { menuView.setVisibility(View.VISIBLE); isHidden = false; }
                            break;
                    }
                    return true;
                }
                return false;
            }
        });
        windowManager.addView(menuView, params);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (menuView != null) windowManager.removeView(menuView);
    }

    @Override
    public IBinder onBind(Intent intent) { return null; }
}
